OK_FORMAT = True

test = {   'name': 'q_acceptance_rates',
    'points': [0.5, 0.5],
    'suites': [   {   'cases': [   {'code': '>>> import numpy as np\n>>> assert np.isclose(acceptance_rate_f, 0.3457532978477204)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(acceptance_rate_m, 0.4427860696517413)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
