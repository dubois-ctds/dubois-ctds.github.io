OK_FORMAT = True

test = {   'name': 'q_num_applicants',
    'points': [1],
    'suites': [   {   'cases': [{'code': ">>> assert list(num_applicants.labels) == ['Major', 'F', 'M']\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
